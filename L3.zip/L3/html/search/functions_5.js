var searchData=
[
  ['node_52',['Node',['../classNode.html#a0d68253f48f4deb1e078ef6cf08a5bf4',1,'Node::Node(int data)'],['../classNode.html#a0d68253f48f4deb1e078ef6cf08a5bf4',1,'Node::Node(int data)']]]
];

var searchData=
[
  ['xork_37',['xorK',['../Q2_8cpp.html#afbc311e0f17a403d378804ce74244262',1,'Q2.cpp']]]
];
